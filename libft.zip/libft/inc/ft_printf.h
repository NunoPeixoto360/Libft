/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 14:20:03 by nmendes-          #+#    #+#             */
/*   Updated: 2023/05/05 15:17:46 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include "stdarg.h"
# include "stdio.h"
# include "unistd.h"

int	ft_printf(const char *str, ...);
int	ft_putchar_len(const char c);
int	ft_putstr_len(char *str);
int	ft_putnbr_len(int nbr);
int	ft_putunbr_len(unsigned int nbr);
int	ft_putnbrhex_len(unsigned int nbr);
int	ft_putnbrhexup_len(unsigned int nbr);
int	ft_ptrhex_len(unsigned long ptr);

#endif