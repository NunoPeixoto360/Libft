/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstlast.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/28 13:18:21 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/28 13:25:22 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstlast(t_list *lst)
{
	t_list	*tmp;

	while (lst)
	{
		tmp = lst->next;
		if (!tmp)
			return (lst);
		lst = lst->next;
	}
	return (NULL);
}
/*
int	main()
{
	char	*s1 = "1";
	char	*s2 = "2";
	char	*s3 = "3";
	t_list	*n1 = ft_lstnew(s1);
	t_list	*n2 = ft_lstnew(s2);
	t_list	*n3 = ft_lstnew(s3);
	t_list	*list;

	n1->next = n2;
	n2->next = n3;
	list = n1;
	printf("%s\n", (char *)ft_lstlast(list)->content);
}*/