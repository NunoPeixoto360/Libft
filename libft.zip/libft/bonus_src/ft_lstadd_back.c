/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/28 13:29:23 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/28 14:10:48 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_back(t_list **lst, t_list *new)
{
	if (!new)
		return ;
	if (!*lst)
	{
		*lst = new;
		return ;
	}
	ft_lstlast(*lst)->next = new;
}
/*
int	main()
{
	char	*s1 = "1";
	char	*s2 = "2";
	char	*stoadd = "0";
	t_list	*n1 = ft_lstnew(s1);
	t_list	*n2 = ft_lstnew(s2);
	t_list	*toadd = ft_lstnew(stoadd);
	t_list	*list;

	n1->next = n2;
	list = n1;
	while (list)
	{
		printf("%s\n", (char *)list->content);
		list = list->next;
	}
	list = n1;
	ft_lstadd_back(&list, toadd);
	while (list)
	{
		printf("%s\n", (char *)list->content);
		list = list->next;
	}
}*/