/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/28 14:31:11 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/28 14:41:13 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void *))
{
	t_list	*next_nod;

	while (*lst)
	{
		next_nod = (*lst)->next;
		ft_lstdelone(*lst, del);
		*lst = next_nod;
	}
	*lst = NULL;
}
