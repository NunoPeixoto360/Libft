/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbrhex_len.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/05 12:54:54 by nmendes-          #+#    #+#             */
/*   Updated: 2023/05/05 15:30:22 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	nbrhex_len(unsigned int nbr)
{
	int	counter;

	counter = 0;
	if (nbr == 0)
		return (1);
	while (nbr > 0)
	{
		nbr /= 16;
		counter++;
	}
	return (counter);
}	

int	ft_putnbrhex_len(unsigned int nbr)
{
	char	*base;

	base = "0123456789abcdef";
	if (nbr >= 16)
		ft_putnbrhex_len(nbr / 16);
	ft_putchar_len(base[nbr % 16]);
	return (nbrhex_len(nbr));
}

int	ft_putnbrhexup_len(unsigned int nbr)
{
	char	*base_up;

	base_up = "0123456789ABCDEF";
	if (nbr >= 16)
		ft_putnbrhexup_len(nbr / 16);
	ft_putchar_len(base_up[nbr % 16]);
	return (nbrhex_len(nbr));
}
