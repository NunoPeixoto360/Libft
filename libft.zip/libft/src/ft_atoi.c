/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/17 19:33:14 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/17 19:33:14 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_isspace(const char *str)
{
	size_t	i;

	i = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == 32)
		i++;
	return (i);
}

static int	digits(const char *str, int index)
{
	size_t	count;

	count = 0;
	while (str[index] >= '0' && str[index] <= '9')
	{
		index++;
		count++;
	}
	return (count);
}

static int	power10(int dig)
{
	int	acc;

	acc = 1;
	while (dig-- > 1)
		acc *= 10;
	return (acc);
}

int	ft_atoi(const char *str)
{
	size_t	i;
	int		sign;
	int		digit;
	long	acc;

	i = ft_isspace(str);
	sign = 1;
	acc = 0;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		i++;
		sign = -1;
	}
	while (digits(str, i) > 0)
	{
		digit = str[i] - '0';
		acc = acc + (digit * power10(digits(str, i)));
		i++;
	}
	if (sign == -1)
		return (acc * -1);
	else
		return (acc);
}
/*
int	main()
{
	char	*nbr = "-+123";
	
	printf("%d\n", ft_atoi(nbr));
	printf("%d\n", atoi(nbr));
}*/