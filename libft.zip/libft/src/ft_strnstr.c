/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/17 19:15:57 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/17 19:15:57 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, size_t len)
{
	size_t	i;
	size_t	j;

	i = 0;
	if (ft_strlen(little) == 0)
		return ((char *)(big));
	if (ft_strlen(little) > ft_strlen(big))
		return (0);
	while (i < len)
	{
		j = 0;
		while (little[j] && i + j < len)
		{
			if (little[j] != big[i + j])
				break ;
			j++;
		}
		if (j == ft_strlen(little))
			return ((char *)(big + i));
		i++;
	}
	return (0);
}
/*
int	main()
{
	char	*big = "";
	char	*little = "xx";

	printf("%s\n", ft_strnstr(big, little, 4294967295));
	printf("%s\n", strnstr(big, little, 4294967295));
}*/