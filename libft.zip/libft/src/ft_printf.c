/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 14:26:29 by nmendes-          #+#    #+#             */
/*   Updated: 2023/05/05 15:30:14 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	formats(va_list args, const char c)
{
	int	length;

	length = 0;
	if (c == '%')
		length = ft_putchar_len(c);
	else if (c == 'c')
		length = ft_putchar_len(va_arg(args, int));
	else if (c == 's')
		length = ft_putstr_len(va_arg(args, char *));
	else if (c == 'p')
		length = ft_ptrhex_len(va_arg(args, unsigned long));
	else if (c == 'd' || c == 'i')
		length = ft_putnbr_len(va_arg(args, int));
	else if (c == 'u')
		length = ft_putunbr_len(va_arg(args, unsigned int));
	else if (c == 'x')
		length = ft_putnbrhex_len(va_arg(args, unsigned int));
	else if (c == 'X')
		length = ft_putnbrhexup_len(va_arg(args, unsigned int));
	return (length);
}

int	ft_printf(const char *str, ...)
{
	int		i;
	int		final_length;
	va_list	args;

	i = 0;
	final_length = 0;
	va_start(args, str);
	while (str[i])
	{
		if (str[i] != '%')
			final_length += ft_putchar_len(str[i]);
		else
			final_length += formats(args, str[++i]);
		i++;
	}
	va_end(args);
	return (final_length);
}
