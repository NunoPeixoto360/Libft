/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 17:24:24 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/26 15:23:53 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	const char	*s;
	char		*d;
	size_t		i;

	s = src;
	d = dest;
	i = n;
	if (src == dest)
		return (dest);
	if (d <= s || d >= s + n)
	{
		d = ft_memcpy(d, s, n);
	}
	else
	{
		while (i > 0)
		{
			i--;
			d[i] = s[i];
		}
	}
	return (dest);
}
/*
int	main()
{
	char	*src = NULL;
	char	*dest = NULL;
	char	*ptr = ft_memmove(dest, src, '\0');

	printf("result: %s\n", ptr);
	printf("expected: %s\n", (char *)memmove(dest, src, '0'));
}
*/