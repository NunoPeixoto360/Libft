/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/14 17:33:00 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/14 17:33:00 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	unsigned int	dst_len;
	unsigned int	src_len;
	unsigned int	rtrn;
	unsigned int	i;

	dst_len = ft_strlen(dst);
	src_len = ft_strlen(src);
	i = 0;
	if (size <= dst_len)
		rtrn = src_len + size;
	else
	{
		rtrn = dst_len + src_len;
		while (src[i] && i + dst_len < size - 1 && size > 0)
		{
			dst[i + dst_len] = src[i];
			i++;
		}
		dst[i + dst_len] = '\0';
	}
	return (rtrn);
}
/*
int	main()
{
	char	dst[50] = "pqrs";
	char	*src = "abcdefghi";
	size_t	newlen = ft_strlcat(dst, src, 10);

	printf("New string = '%s', size = %zu\n", dst, newlen);
}*/