/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ptrhex_len.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/05 13:40:48 by nmendes-          #+#    #+#             */
/*   Updated: 2023/05/05 16:16:10 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	ptrlen(unsigned long ptr)
{
	int	counter;

	counter = 0;
	if (ptr == 0)
		return (1);
	while (ptr > 0)
	{
		ptr /= 16;
		counter++;
	}
	return (counter);
}

static void	print_ptr(unsigned long ptr)
{
	char	*base;

	base = "0123456789abcdef";
	if (ptr >= 16)
		print_ptr(ptr / 16);
	ft_putchar_len(base[ptr % 16]);
}

int	ft_ptrhex_len(unsigned long ptr)
{
	int	length;

	length = 0;
	if (ptr == 0)
		return (write (1, "(nil)", 5));
	length += write(1, "0x", 2);
	print_ptr(ptr);
	length += ptrlen(ptr);
	return (length);
}
