/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_len.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/05 11:51:50 by nmendes-          #+#    #+#             */
/*   Updated: 2023/05/05 15:30:20 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	nbr_len(unsigned int nbr)
{
	int	counter;

	counter = 0;
	if (nbr == 0)
		return (1);
	while (nbr != 0)
	{
		nbr /= 10;
		counter++;
	}
	return (counter);
}

int	ft_putnbr_len(int nbr)
{
	unsigned int	u;
	int				length;

	u = nbr;
	length = 0;
	if (nbr < 0)
	{
		length = ft_putchar_len('-');
		u = nbr * -1;
	}
	length += nbr_len(u);
	if (u >= 10)
		ft_putnbr_len(u / 10);
	ft_putchar_len(u % 10 + '0');
	return (length);
}

int	ft_putunbr_len(unsigned int nbr)
{
	int	length;

	length = nbr_len(nbr);
	if (nbr >= 10)
		ft_putunbr_len(nbr / 10);
	ft_putchar_len(nbr % 10 + '0');
	return (length);
}
