/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/17 17:54:08 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/17 17:54:08 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *str, int c)
{
	size_t			i;
	unsigned char	ch;

	i = 0;
	ch = c;
	while (str[i])
	{
		if (str[i] == ch)
			return ((char *)(str + i));
		i++;
	}
	if (ch == 0)
		return ((char *)(str + i));
	else
		return (0);
}
/*
int	main()
{
	char	*str = "teste";
	int	to_find = 1024;

	printf("%s\n", ft_strchr(str, to_find));
	printf("%s\n", strchr(str, to_find));
}*/