/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/21 13:14:41 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/21 13:14:41 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putnbr_fd(int n, int fd)
{
	unsigned int	un;

	un = n;
	if (n < 0)
	{
		un = -n;
		ft_putchar_fd('-', fd);
	}
	if (un > 9)
	{
		ft_putnbr_fd(un / 10, fd);
		un %= 10;
	}
	ft_putchar_fd(un + '0', fd);
}
/*
int	main()
{
	int	nb = -2147483648;

	ft_putnbr_fd(nb, 1);
}*/