/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/17 17:51:43 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/17 17:51:43 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_tolower(int c)
{
	if (c >= 'A' && c <= 'Z')
		return (c + 32);
	return (c);
}
/*
int	main()
{
	char c = 'b';
	char c2 = 'Z';
	char c3 = '2';

	printf("%c\n", ft_tolower(c));
	printf("%c\n", ft_tolower(c2));
	printf("%c\n", ft_tolower(c3));
}*/