/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/19 13:05:11 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/19 13:05:11 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	i;
	size_t	subs_len;
	char	*subs;

	i = 0;
	subs_len = 0;
	if (start >= ft_strlen(s))
	{
		subs = (char *)malloc (sizeof(char) * 1);
		subs[i] = '\0';
		return (subs);
	}
	while (s[start + subs_len] && subs_len < len)
		subs_len++;
	subs = (char *)malloc (sizeof(char) * (subs_len + 1));
	if (subs == NULL)
		return (NULL);
	while (i < len && s[start + i])
	{
		subs[i] = s[start + i];
		i++;
	}
	subs[i] = '\0';
	return (subs);
}
/*
int main()
{
	char	*original = "";

	printf("%s\n", ft_substr(original, 5, 0));
	printf("%s\n", substr(original, 5, 0));
}*/