/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 15:48:55 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/13 16:46:13 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *s, int c, size_t n)
{
	unsigned char	char_value;
	unsigned char	*p;
	size_t			i;

	i = 0;
	char_value = c;
	p = s;
	while (i < n)
		p[i++] = char_value;
	return (s);
}
/*
int	main()
{
	char	str[] = "Hello";
	
	ft_memset(str, 'b', 6);
	printf("%s\n", str);
}*/
