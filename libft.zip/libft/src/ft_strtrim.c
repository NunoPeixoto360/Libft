/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/19 16:29:36 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/19 16:29:36 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	size_t	start;
	size_t	end;
	char	*trimmed;

	start = 0;
	end = ft_strlen(s1);
	while (s1[start] && ft_strchr(set, s1[start]))
		start++;
	while (end > start && ft_strchr(set, s1[end - 1]))
		end--;
	if (!ft_strlen(s1) || start > end || !s1)
	{
		trimmed = (char *)malloc (1 * sizeof(char));
		trimmed[0] = '\0';
		return (trimmed);
	}
	trimmed = (char *)malloc (sizeof(char) * ((end - start) + 1));
	if (trimmed == NULL)
		return (NULL);
	ft_strlcpy(trimmed, (char *)&s1[start], end - start + 1);
	return (trimmed);
}

int	main()
{
	char	*src = "ohlhoo";
	char	*set = "oh";

	printf("Original: '%s'\n", src);
	printf("Trimmed: '%s'\n", ft_strtrim(src, set));
}