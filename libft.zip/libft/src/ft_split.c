/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/19 17:54:45 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/19 17:54:45 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char	*new_word(char const *s, char c, size_t index)
{
	size_t	i;
	size_t	word_len;
	char	*word;

	i = 0;
	word_len = 0;
	while (s[index + word_len] != c && s[index + word_len])
		word_len++;
	word = (char *)malloc (sizeof(char) * (word_len + 1));
	while (i < word_len)
	{
		word[i] = s[index + i];
		i++;
	}
	word[i] = '\0';
	return (word);
}

static size_t	nwords(char const *s, char c)
{
	size_t	count;
	size_t	i;

	count = 0;
	i = 0;
	while (s[i])
	{
		if (s[i] == c)
			i++;
		else
		{
			while (s[i] != c && s[i])
				i++;
			count++;
		}
	}
	return (count);
}

char	**ft_split(char const *s, char c)
{
	size_t	i;
	size_t	j;
	char	**words;

	i = 0;
	j = 0;
	words = (char **)malloc (sizeof(char *) * (nwords(s, c) + 1));
	if (!words)
		return (NULL);
	while (s[i])
	{
		if (s[i] == c)
			i++;
		else
		{
			words[j] = new_word(s, c, i);
			j++;
			while (s[i] != c && s[i])
				i++;
		}
	}
	words[j] = NULL;
	return (words);
}
/*
int	main()
{
	char	*str = "Hellozzzzzzz";
	char	sep = 'z';
	char	**strs = ft_split(str, sep);
	int		i = 0;

	while (i < nwords(str, sep))
	{
		printf("word %i :'%s'\n", i, strs[i]);
		i++;
	}
}*/