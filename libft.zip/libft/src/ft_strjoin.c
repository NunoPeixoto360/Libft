/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/19 13:21:11 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/19 13:21:11 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	i;
	size_t	j;
	char	*newstr;
	int		newstr_len;

	i = 0;
	j = 0;
	newstr_len = ft_strlen(s1) + ft_strlen(s2) + 1;
	newstr = (char *)malloc (sizeof(char) * (newstr_len));
	if (newstr == NULL)
		return (NULL);
	while (s1[j])
	{
		newstr[j] = s1[j];
		j++;
	}
	while (s2[i])
	{
		newstr[ft_strlen(s1) + i] = s2[i];
		i++;
	}
	newstr[newstr_len - 1] = '\0';
	return (newstr);
}
/*
int	main()
{
	char	*s1 = "Hello ";
	char	*s2 = "World!";
	char	*joined = ft_strjoin(s1, s2);

	printf("%s\n", joined);
}*/