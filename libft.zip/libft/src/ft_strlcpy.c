/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strlcpy.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/14 16:38:26 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/14 16:38:26 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	const char	*s;
	char		*d;
	size_t		i;

	s = src;
	d = dst;
	i = 0;
	while (s[i] && i < size - 1 && size > 0)
	{
		d[i] = s[i];
		i++;
	}
	if (size > 0)
		d[i] = '\0';
	while (s[i])
		i++;
	return (i);
}
/*
int	main()
{
	char	*src = "Hello";
	char	*d = malloc (sizeof(char) * ft_strlen(src) + 1);
	
	printf("%d\n", ft_strlcpy(d, src, 2));
	printf("%s\n", d);
}*/