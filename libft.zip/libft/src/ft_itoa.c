/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nmendes- <nmendes-@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/21 09:05:11 by nmendes-          #+#    #+#             */
/*   Updated: 2023/04/21 09:05:11 by nmendes-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ndigits(int n)
{
	int	count;

	count = 0;
	while (n != 0)
	{
		n /= 10;
		count++;
	}
	return (count);
}

static void	helper(char *buffer, int n, int sign)
{
	int				i;
	unsigned int	un;

	if (n < 0)
	{
		un = n * -1;
		buffer[0] = '-';
	}
	else
		un = n;
	i = ndigits(n) + sign - 1;
	while (ndigits(un) > 0)
	{
		buffer[i--] = un % 10 + '0';
		un /= 10;
	}
	if (n == 0)
		buffer[0] = '0';
	buffer[ndigits(n) + sign] = '\0';
}

char	*ft_itoa(int n)
{
	char			*buffer;
	int				sign;

	sign = 0;
	if (n <= 0)
		sign = 1;
	buffer = (char *)malloc (sizeof(char) * (ndigits(n) + sign + 1));
	if (!buffer)
		return (NULL);
	helper(buffer, n, sign);
	return (buffer);
}
/*
int	main()
{
	int	nb = -2147483648;
	
	printf("%s\n", ft_itoa(nb));
}*/